/*
 * Copyright (c) 2006-2021, RT-Thread Development Team
 *
 * SPDX-License-Identifier: Apache-2.0
 *
 * Change Logs:
 * Date           Author       Notes
 * 2025-06-05     zhr       the first version
 */
#ifndef APPLICATIONS_LED_H_
#define APPLICATIONS_LED_H_



#endif /* APPLICATIONS_LED_H_ */
